package mother.library;
import java.util.Date;

import com.illposed.osc.OSCMessage;

public class Message
{
	public Date time;
	public OSCMessage message;
}
